package com.claude.salwana.salwana_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
