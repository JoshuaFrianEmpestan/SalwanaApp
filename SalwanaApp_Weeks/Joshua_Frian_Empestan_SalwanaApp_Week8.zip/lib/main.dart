import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'firebase_options.dart';
import 'screens/categories_screen.dart';
import 'screens/home_screen.dart';
import 'widgets/adaptive_nav_scaffold.dart';
import 'widgets/offline_banner.dart';

/// Run with `--dart-define=USE_FIREBASE_EMULATOR=true` to point at the
/// local Firebase Emulator Suite (`firebase emulators:start`) instead of a
/// real project. Never true in a release build.
const _useFirebaseEmulator = bool.fromEnvironment('USE_FIREBASE_EMULATOR');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  // Week 7: offline support — cache reads and queue writes locally so the
  // app stays usable when connectivity drops.
  try {
    FirebaseFirestore.instance.settings = const Settings(
      persistenceEnabled: true,
      cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
    );
  } catch (_) {
    // Persistence unavailable (e.g. multiple open web tabs) — the app
    // still works, just without an offline cache.
  }

  if (_useFirebaseEmulator) {
    // Literal 127.0.0.1, not "localhost" — on Windows "localhost" can
    // resolve to the IPv6 loopback first, which the emulator (bound to
    // 127.0.0.1 only) never answers on.
    FirebaseFirestore.instance.useFirestoreEmulator('127.0.0.1', 8081);
  }

  runApp(const ProviderScope(child: SalwanaApp()));
}

class SalwanaApp extends StatelessWidget {
  const SalwanaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Salwana Retail Stock Tracker',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.green),
        useMaterial3: true,
      ),
      builder: (context, child) => OfflineBanner(child: child ?? const SizedBox.shrink()),
      home: const AdaptiveNavScaffold(
        screens: [HomeScreen(), CategoriesScreen()],
        destinations: [
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2), label: 'Inventory'),
          NavigationDestination(icon: Icon(Icons.category_outlined), selectedIcon: Icon(Icons.category), label: 'Categories'),
        ],
      ),
    );
  }
}
