import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/inventory_item.dart';
import '../services/inventory_provider.dart';
import 'item_form_screen.dart';

/// Item Detail screen (Week 2). Week 3 adds the Edit action; Week 5 has
/// Edit and the Stock In/Out buttons write straight to Firestore through
/// [inventoryRepositoryProvider]. Week 7: this screen now also *watches*
/// [inventoryProvider] and looks itself up by SKU, so a Stock In/Out
/// updates the quantity in place (animated via [AnimatedSwitcher])
/// instead of immediately popping back to the list.
class ItemDetailScreen extends ConsumerWidget {
  final InventoryItem item;

  const ItemDetailScreen({super.key, required this.item});

  Future<void> _edit(BuildContext context, WidgetRef ref, InventoryItem current) async {
    final result = await Navigator.of(context).push<InventoryItem>(
      MaterialPageRoute(builder: (_) => ItemFormScreen(initial: current)),
    );
    if (result != null) {
      await ref.read(inventoryRepositoryProvider).updateItem(result);
      if (context.mounted) Navigator.of(context).pop();
    }
  }

  Future<void> _adjustStock(WidgetRef ref, InventoryItem current, int delta) {
    return ref.read(inventoryRepositoryProvider).adjustQuantity(current, delta);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final itemsAsync = ref.watch(inventoryProvider);
    final matches = itemsAsync.valueOrNull?.where((i) => i.sku == item.sku).toList() ?? const [];
    final current = matches.isNotEmpty ? matches.first : item;
    final outOfStock = current.quantity == 0;

    return Scaffold(
      appBar: AppBar(
        title: Text(current.name),
        actions: [
          IconButton(icon: const Icon(Icons.edit_outlined), tooltip: 'Edit item', onPressed: () => _edit(context, ref, current)),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Hero(
              tag: 'item-icon-${current.sku}',
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(Icons.inventory_2_outlined, size: 64, color: Theme.of(context).colorScheme.primary),
              ),
            ),
            const SizedBox(height: 24),
            Text(current.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 16),
            _DetailRow(label: 'SKU / Code', value: current.sku),
            _DetailRow(label: 'Category', value: current.category),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Row(
                children: [
                  SizedBox(width: 110, child: Text('Quantity', style: TextStyle(color: Colors.grey.shade600, fontSize: 13))),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 200),
                    transitionBuilder: (child, animation) => ScaleTransition(scale: animation, child: child),
                    child: Text(
                      '${current.quantity}',
                      key: ValueKey(current.quantity),
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: outOfStock ? Colors.red.shade700 : Colors.green.shade700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (outOfStock) ...[
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: Colors.red.shade50, borderRadius: BorderRadius.circular(10)),
                child: Row(
                  children: [
                    Icon(Icons.warning_amber_rounded, color: Colors.red.shade700, size: 20),
                    const SizedBox(width: 8),
                    Expanded(child: Text('This item is out of stock.', style: TextStyle(color: Colors.red.shade700, fontWeight: FontWeight.w600))),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 24),
            Text('Stock In / Stock Out', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: Colors.grey.shade600)),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: current.quantity == 0 ? null : () => _adjustStock(ref, current, -1),
                    icon: const Icon(Icons.remove_circle_outline_rounded),
                    label: const Text('Stock Out'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: () => _adjustStock(ref, current, 1),
                    icon: const Icon(Icons.add_circle_outline_rounded),
                    label: const Text('Stock In'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;

  const _DetailRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          SizedBox(width: 110, child: Text(label, style: TextStyle(color: Colors.grey.shade600, fontSize: 13))),
          Expanded(
            child: Text(value, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }
}
