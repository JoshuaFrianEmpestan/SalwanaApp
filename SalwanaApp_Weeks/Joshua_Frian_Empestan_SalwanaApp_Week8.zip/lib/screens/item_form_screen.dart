import 'package:flutter/material.dart';
import '../models/inventory_item.dart';
import '../widgets/responsive_form_body.dart';

/// Add/Edit Item form (Week 3). Pass [initial] to edit an existing item,
/// or omit it to add a new one. Pops with the resulting [InventoryItem] on
/// save, or null if the user backs out.
class ItemFormScreen extends StatefulWidget {
  final InventoryItem? initial;

  const ItemFormScreen({super.key, this.initial});

  @override
  State<ItemFormScreen> createState() => _ItemFormScreenState();
}

class _ItemFormScreenState extends State<ItemFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _sku;
  late final TextEditingController _quantity;
  late final TextEditingController _category;

  @override
  void initState() {
    super.initState();
    final item = widget.initial;
    _name = TextEditingController(text: item?.name ?? '');
    _sku = TextEditingController(text: item?.sku ?? '');
    _quantity = TextEditingController(text: item != null ? '${item.quantity}' : '');
    _category = TextEditingController(text: item?.category ?? '');
  }

  @override
  void dispose() {
    _name.dispose();
    _sku.dispose();
    _quantity.dispose();
    _category.dispose();
    super.dispose();
  }

  String? _required(String? v, {required String field}) {
    if (v == null || v.trim().isEmpty) return '$field is required';
    return null;
  }

  String? _validateQuantity(String? v) {
    if (v == null || v.trim().isEmpty) return 'Quantity is required';
    final n = int.tryParse(v.trim());
    if (n == null) return 'Quantity must be a whole number';
    if (n < 0) return 'Quantity cannot be negative';
    return null;
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    Navigator.of(context).pop(
      InventoryItem(
        name: _name.text.trim(),
        sku: _sku.text.trim(),
        quantity: int.parse(_quantity.text.trim()),
        category: _category.text.trim(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.initial != null;
    return Scaffold(
      appBar: AppBar(title: Text(isEdit ? 'Edit Item' : 'Add Item')),
      body: SafeArea(
        child: ResponsiveFormBody(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextFormField(
                    controller: _name,
                    decoration: const InputDecoration(labelText: 'Item Name'),
                    validator: (v) => _required(v, field: 'Item name'),
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _sku,
                    decoration: const InputDecoration(labelText: 'SKU / Code'),
                    validator: (v) => _required(v, field: 'SKU'),
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _quantity,
                    decoration: const InputDecoration(labelText: 'Quantity'),
                    keyboardType: TextInputType.number,
                    validator: _validateQuantity,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _category,
                    decoration: const InputDecoration(labelText: 'Category'),
                    validator: (v) => _required(v, field: 'Category'),
                  ),
                  const SizedBox(height: 28),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: _save,
                      child: Text(isEdit ? 'Save Changes' : 'Add Item'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
