import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/inventory_item.dart';
import '../services/inventory_provider.dart';
import '../widgets/inventory_item_card.dart';
import 'item_detail_screen.dart';
import 'item_form_screen.dart';

/// Home/Item List screen (Week 1). Responsive layout: a single-column list
/// on phone-width screens, a multi-column grid on tablet/wide screens —
/// driven by [LayoutBuilder] reading the available width, not the device
/// type, so it also works with a resized desktop window — including a
/// rotation, since it's width-driven rather than orientation-cased
/// (Week 6).
///
/// Week 5: [inventoryProvider] is now backed by Firestore, so this reads
/// an [AsyncValue] and shows explicit loading/error states instead of
/// assuming the data is already there.
///
/// Week 6: search + category filter (kept in local widget state, which
/// Flutter preserves across a rotation) and a low-stock alert banner.
class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  static const double _tabletBreakpoint = 600;
  static const int _lowStockThreshold = 10;

  final _searchController = TextEditingController();
  String _search = '';
  String _categoryFilter = 'All';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  int _columnsFor(double width) {
    if (width >= 1000) return 4;
    if (width >= _tabletBreakpoint) return 3;
    return 1;
  }

  List<InventoryItem> _applyFilters(List<InventoryItem> items) {
    return items.where((item) {
      final matchesSearch = _search.isEmpty ||
          item.name.toLowerCase().contains(_search.toLowerCase()) ||
          item.sku.toLowerCase().contains(_search.toLowerCase());
      final matchesCategory = _categoryFilter == 'All' || item.category == _categoryFilter;
      return matchesSearch && matchesCategory;
    }).toList();
  }

  Future<void> _openDetail(InventoryItem item) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => ItemDetailScreen(item: item)));
  }

  Future<void> _addItem() async {
    final result = await Navigator.of(context).push<InventoryItem>(
      MaterialPageRoute(builder: (_) => const ItemFormScreen()),
    );
    if (result != null) {
      await ref.read(inventoryRepositoryProvider).addItem(result);
    }
  }

  @override
  Widget build(BuildContext context) {
    final itemsAsync = ref.watch(inventoryProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Retail Stock Tracker')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addItem,
        icon: const Icon(Icons.add),
        label: const Text('Add Item'),
      ),
      body: SafeArea(
        child: itemsAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, _) => Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.error_outline_rounded, size: 40, color: Colors.red),
                  const SizedBox(height: 12),
                  const Text('Could not load inventory.', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  Text('$error', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                  const SizedBox(height: 16),
                  FilledButton.icon(
                    onPressed: () => ref.invalidate(inventoryProvider),
                    icon: const Icon(Icons.refresh_rounded),
                    label: const Text('Retry'),
                  ),
                ],
              ),
            ),
          ),
          data: (items) {
            if (items.isEmpty) {
              return const Center(child: Text('No items yet. Tap "Add Item" to get started.'));
            }

            final lowStock = items.where((i) => i.quantity > 0 && i.quantity <= _lowStockThreshold).length;
            final categories = ['All', ...{for (final i in items) i.category}];
            final filtered = _applyFilters(items);

            return Column(
              children: [
                if (lowStock > 0)
                  Container(
                    width: double.infinity,
                    color: Colors.orange.shade50,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    child: Row(
                      children: [
                        Icon(Icons.warning_amber_rounded, size: 18, color: Colors.orange.shade800),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            '$lowStock item${lowStock == 1 ? ' is' : 's are'} running low on stock (≤ $_lowStockThreshold).',
                            style: TextStyle(color: Colors.orange.shade900, fontSize: 12, fontWeight: FontWeight.w600),
                          ),
                        ),
                      ],
                    ),
                  ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                  child: TextField(
                    controller: _searchController,
                    onChanged: (v) => setState(() => _search = v),
                    decoration: const InputDecoration(
                      hintText: 'Search by name or SKU',
                      prefixIcon: Icon(Icons.search_rounded),
                      isDense: true,
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                SizedBox(
                  height: 36,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    children: [
                      for (final category in categories)
                        Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ChoiceChip(
                            label: Text(category),
                            selected: _categoryFilter == category,
                            onSelected: (_) => setState(() => _categoryFilter = category),
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Expanded(
                  child: filtered.isEmpty
                      ? const Center(child: Text('No items match your search/filter.'))
                      : LayoutBuilder(
                          builder: (context, constraints) {
                            final columns = _columnsFor(constraints.maxWidth);

                            if (columns == 1) {
                              return ListView.separated(
                                padding: const EdgeInsets.fromLTRB(16, 0, 16, 88),
                                itemCount: filtered.length,
                                separatorBuilder: (_, _) => const SizedBox(height: 10),
                                itemBuilder: (context, index) => InventoryItemCard(item: filtered[index], onTap: () => _openDetail(filtered[index])),
                              );
                            }

                            return GridView.builder(
                              padding: const EdgeInsets.fromLTRB(16, 0, 16, 88),
                              itemCount: filtered.length,
                              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: columns,
                                mainAxisSpacing: 12,
                                crossAxisSpacing: 12,
                                childAspectRatio: 1.4,
                              ),
                              itemBuilder: (context, index) => InventoryItemCard(item: filtered[index], onTap: () => _openDetail(filtered[index])),
                            );
                          },
                        ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
