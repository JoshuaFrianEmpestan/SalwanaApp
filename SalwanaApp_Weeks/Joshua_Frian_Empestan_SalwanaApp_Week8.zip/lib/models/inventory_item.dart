/// A single stock item in the retail inventory. Week 5 adds Firestore
/// (de)serialization now that this is backed by a real database instead
/// of hardcoded dummy data.
class InventoryItem {
  final String name;
  final String sku;
  final int quantity;
  final String category;

  const InventoryItem({
    required this.name,
    required this.sku,
    required this.quantity,
    required this.category,
  });

  InventoryItem copyWith({int? quantity}) {
    return InventoryItem(name: name, sku: sku, quantity: quantity ?? this.quantity, category: category);
  }

  Map<String, dynamic> toMap() {
    return {'name': name, 'sku': sku, 'quantity': quantity, 'category': category};
  }

  factory InventoryItem.fromMap(Map<String, dynamic> map) {
    return InventoryItem(
      name: map['name'] as String,
      sku: map['sku'] as String,
      quantity: map['quantity'] as int,
      category: map['category'] as String,
    );
  }
}
