// GENERATED PLACEHOLDER — replace this entire file by running:
//
//   dart pub global activate flutterfire_cli
//   flutterfire configure
//
// from the project root, after creating a Firebase project and enabling
// Firestore. The CLI overwrites this file with your real project's keys.

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart' show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not configured for this platform. '
          'Run `flutterfire configure` to generate real options.',
        );
    }
  }

  // Well-formed but fake ("demo-" project) values — satisfy the SDK's
  // local format validation and work against the Firebase Local Emulator
  // Suite (see USE_FIREBASE_EMULATOR in main.dart), but are NOT a real
  // project and will not work against production Firebase.
  static const web = FirebaseOptions(
    apiKey: 'demo-api-key',
    appId: '1:1234567890:web:abcdef1234567890abcdef',
    messagingSenderId: '1234567890',
    projectId: 'demo-salwana-retail',
    authDomain: 'demo-salwana-retail.firebaseapp.com',
    storageBucket: 'demo-salwana-retail.appspot.com',
  );

  static const android = FirebaseOptions(
    apiKey: 'demo-api-key',
    appId: '1:1234567890:android:abcdef1234567890abcdef',
    messagingSenderId: '1234567890',
    projectId: 'demo-salwana-retail',
    storageBucket: 'demo-salwana-retail.appspot.com',
  );

  static const ios = FirebaseOptions(
    apiKey: 'demo-api-key',
    appId: '1:1234567890:ios:abcdef1234567890abcdef',
    messagingSenderId: '1234567890',
    projectId: 'demo-salwana-retail',
    storageBucket: 'demo-salwana-retail.appspot.com',
    iosBundleId: 'com.claude.salwana.salwanaApp',
  );
}
