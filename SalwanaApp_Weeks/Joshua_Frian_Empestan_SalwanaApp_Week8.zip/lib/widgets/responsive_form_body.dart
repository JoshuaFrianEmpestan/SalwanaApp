import 'package:flutter/widgets.dart';

/// Caps and centers form content on wide screens instead of stretching a
/// single-column form edge to edge on tablet/desktop widths.
class ResponsiveFormBody extends StatelessWidget {
  final Widget child;
  final double maxWidth;

  const ResponsiveFormBody({super.key, required this.child, this.maxWidth = 520});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(constraints: BoxConstraints(maxWidth: maxWidth), child: child),
    );
  }
}
