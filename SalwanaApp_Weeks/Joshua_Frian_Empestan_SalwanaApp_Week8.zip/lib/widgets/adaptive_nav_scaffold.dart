import 'package:flutter/material.dart';

/// Adaptive navigation shell (Week 2): a bottom navigation bar on phone
/// widths, a side [NavigationRail] on tablet/wide widths — same widget
/// tree, just arranged by available width via [LayoutBuilder].
class AdaptiveNavScaffold extends StatefulWidget {
  final List<Widget> screens;
  final List<NavigationDestination> destinations;

  const AdaptiveNavScaffold({super.key, required this.screens, required this.destinations});

  @override
  State<AdaptiveNavScaffold> createState() => _AdaptiveNavScaffoldState();
}

class _AdaptiveNavScaffoldState extends State<AdaptiveNavScaffold> {
  int _index = 0;

  static const double _tabletBreakpoint = 600;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isWide = constraints.maxWidth >= _tabletBreakpoint;

        if (!isWide) {
          return Scaffold(
            body: widget.screens[_index],
            bottomNavigationBar: NavigationBar(
              selectedIndex: _index,
              onDestinationSelected: (i) => setState(() => _index = i),
              destinations: widget.destinations,
            ),
          );
        }

        return Scaffold(
          body: Row(
            children: [
              NavigationRail(
                selectedIndex: _index,
                onDestinationSelected: (i) => setState(() => _index = i),
                labelType: NavigationRailLabelType.all,
                destinations: [
                  for (final d in widget.destinations)
                    NavigationRailDestination(icon: d.icon, selectedIcon: d.selectedIcon, label: Text(d.label)),
                ],
              ),
              const VerticalDivider(width: 1),
              Expanded(child: widget.screens[_index]),
            ],
          ),
        );
      },
    );
  }
}
