import 'package:flutter/material.dart';
import '../models/inventory_item.dart';

/// Single item card, shared by both the list (phone) and grid (tablet)
/// layouts on the Home screen — same widget, just arranged differently.
class InventoryItemCard extends StatelessWidget {
  final InventoryItem item;
  final VoidCallback? onTap;

  const InventoryItemCard({super.key, required this.item, this.onTap});

  @override
  Widget build(BuildContext context) {
    final outOfStock = item.quantity == 0;
    return Card(
      margin: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Hero(
                  tag: 'item-icon-${item.sku}',
                  child: Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.4),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(Icons.inventory_2_outlined, size: 18, color: Theme.of(context).colorScheme.primary),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    item.name,
                    style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                if (outOfStock)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(color: Colors.red.shade50, borderRadius: BorderRadius.circular(20)),
                    child: Text('OUT OF STOCK', style: TextStyle(color: Colors.red.shade700, fontSize: 10, fontWeight: FontWeight.w700)),
                  ),
              ],
            ),
            const SizedBox(height: 6),
            Text('SKU: ${item.sku}', style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
            const SizedBox(height: 4),
            Text(item.category, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
            const Spacer(),
            Align(
              alignment: Alignment.bottomRight,
              child: Text(
                'Qty: ${item.quantity}',
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 14,
                  color: outOfStock ? Colors.red.shade700 : Colors.green.shade700,
                ),
              ),
            ),
          ],
        ),
        ),
      ),
    );
  }
}
