import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/inventory_item.dart';

/// Week 5: real backend/database integration — items live in a Firestore
/// `items` collection (document ID = SKU) instead of an in-memory list.
/// Also carries the Stock In/Out actions (adjustQuantity), since both are
/// this week's requirement together.
class InventoryService {
  final _collection = FirebaseFirestore.instance.collection('items');

  Stream<List<InventoryItem>> watchItems() {
    return _collection.orderBy('name').snapshots().map(
          (snapshot) => snapshot.docs.map((doc) => InventoryItem.fromMap(doc.data())).toList(),
        );
  }

  Future<void> addItem(InventoryItem item) => _collection.doc(item.sku).set(item.toMap());

  Future<void> updateItem(InventoryItem item) => _collection.doc(item.sku).set(item.toMap());

  /// Stock In (positive delta) / Stock Out (negative delta). Clamped so
  /// quantity never goes below zero.
  Future<void> adjustQuantity(InventoryItem item, int delta) {
    final next = (item.quantity + delta).clamp(0, 1 << 31);
    return updateItem(item.copyWith(quantity: next));
  }

  /// Seeds the same starter catalog used in Weeks 1-4, so the collection
  /// isn't empty the first time this runs against a fresh database.
  Future<void> seedIfEmpty() async {
    final existing = await _collection.limit(1).get();
    if (existing.docs.isNotEmpty) return;

    final batch = FirebaseFirestore.instance.batch();
    for (final item in _starterItems) {
      batch.set(_collection.doc(item.sku), item.toMap());
    }
    await batch.commit();
  }

  static const _starterItems = [
    InventoryItem(name: 'Wireless Mouse', sku: 'RS-1001', quantity: 42, category: 'Electronics'),
    InventoryItem(name: 'Mechanical Keyboard', sku: 'RS-1002', quantity: 15, category: 'Electronics'),
    InventoryItem(name: 'USB-C Cable 2m', sku: 'RS-1003', quantity: 120, category: 'Accessories'),
    InventoryItem(name: 'Bluetooth Speaker', sku: 'RS-1004', quantity: 8, category: 'Electronics'),
    InventoryItem(name: 'Notebook A5', sku: 'RS-2001', quantity: 200, category: 'Office Supplies'),
    InventoryItem(name: 'Ballpoint Pen (Box)', sku: 'RS-2002', quantity: 75, category: 'Office Supplies'),
    InventoryItem(name: 'Sticky Notes', sku: 'RS-2003', quantity: 60, category: 'Office Supplies'),
    InventoryItem(name: 'Desk Lamp', sku: 'RS-3001', quantity: 5, category: 'Furniture'),
    InventoryItem(name: 'Office Chair', sku: 'RS-3002', quantity: 3, category: 'Furniture'),
    InventoryItem(name: 'Whiteboard 60x90', sku: 'RS-3003', quantity: 12, category: 'Furniture'),
    InventoryItem(name: 'Phone Stand', sku: 'RS-1005', quantity: 30, category: 'Accessories'),
    InventoryItem(name: 'Laptop Sleeve 14"', sku: 'RS-1006', quantity: 0, category: 'Accessories'),
  ];
}
