import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/inventory_item.dart';
import 'inventory_service.dart';

/// Week 5: [inventoryProvider] is now a [StreamProvider] backed by
/// Firestore, so every screen gets real loading/error/data states
/// ([AsyncValue]) instead of a plain list. Writes go through
/// [inventoryRepositoryProvider] directly — the stream picks up the
/// change automatically once Firestore confirms it.
final inventoryRepositoryProvider = Provider<InventoryService>((ref) => InventoryService());

final inventoryProvider = StreamProvider<List<InventoryItem>>((ref) {
  final repository = ref.watch(inventoryRepositoryProvider);
  repository.seedIfEmpty();
  return repository.watchItems();
});
