import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:salwana_app/main.dart';
import 'package:salwana_app/models/inventory_item.dart';
import 'package:salwana_app/services/inventory_provider.dart';

void main() {
  testWidgets('Home screen shows the inventory list', (WidgetTester tester) async {
    await tester.pumpWidget(
      ProviderScope(
        overrides: [
          inventoryProvider.overrideWith((ref) => Stream.value(const [
                InventoryItem(name: 'Wireless Mouse', sku: 'RS-1001', quantity: 42, category: 'Electronics'),
              ])),
        ],
        child: const SalwanaApp(),
      ),
    );
    await tester.pump();

    expect(find.text('Retail Stock Tracker'), findsOneWidget);
    expect(find.text('Wireless Mouse'), findsOneWidget);
  });
}
