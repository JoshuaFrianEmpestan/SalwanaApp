import 'package:flutter/material.dart';
import '../models/inventory_item.dart';
import '../services/inventory_service.dart';
import '../widgets/inventory_item_card.dart';

/// Home/Item List screen (Week 1). Responsive layout: a single-column list
/// on phone-width screens, a multi-column grid on tablet/wide screens —
/// driven by [LayoutBuilder] reading the available width, not the device
/// type, so it also works with a resized desktop window.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  static const double _tabletBreakpoint = 600;

  int _columnsFor(double width) {
    if (width >= 1000) return 4;
    if (width >= _tabletBreakpoint) return 3;
    return 1;
  }

  @override
  Widget build(BuildContext context) {
    final List<InventoryItem> items = InventoryService().getItems();

    return Scaffold(
      appBar: AppBar(title: const Text('Retail Stock Tracker')),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final columns = _columnsFor(constraints.maxWidth);

            if (columns == 1) {
              return ListView.separated(
                padding: const EdgeInsets.all(16),
                itemCount: items.length,
                separatorBuilder: (_, _) => const SizedBox(height: 10),
                itemBuilder: (context, index) => InventoryItemCard(item: items[index]),
              );
            }

            return GridView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: items.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: columns,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.4,
              ),
              itemBuilder: (context, index) => InventoryItemCard(item: items[index]),
            );
          },
        ),
      ),
    );
  }
}
