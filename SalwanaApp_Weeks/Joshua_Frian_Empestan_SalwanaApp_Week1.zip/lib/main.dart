import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const SalwanaApp());
}

class SalwanaApp extends StatelessWidget {
  const SalwanaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Salwana Retail Stock Tracker',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.green),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}
