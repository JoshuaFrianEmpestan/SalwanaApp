import 'package:flutter/material.dart';
import '../services/inventory_service.dart';

/// Categories overview — the second nav destination, so the adaptive
/// bottom-bar/rail switch (Week 2) has more than one real screen to switch
/// between.
class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final items = InventoryService().getItems();
    final byCategory = <String, int>{};
    for (final item in items) {
      byCategory[item.category] = (byCategory[item.category] ?? 0) + 1;
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Categories')),
      body: SafeArea(
        child: ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: byCategory.length,
          separatorBuilder: (_, _) => const SizedBox(height: 10),
          itemBuilder: (context, index) {
            final entry = byCategory.entries.elementAt(index);
            return Card(
              margin: EdgeInsets.zero,
              child: ListTile(
                leading: const Icon(Icons.category_outlined),
                title: Text(entry.key, style: const TextStyle(fontWeight: FontWeight.w700)),
                trailing: Text('${entry.value} item${entry.value == 1 ? '' : 's'}', style: TextStyle(color: Colors.grey.shade600)),
              ),
            );
          },
        ),
      ),
    );
  }
}
