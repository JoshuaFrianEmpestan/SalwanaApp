import 'package:flutter/material.dart';
import '../models/inventory_item.dart';
import '../services/inventory_service.dart';
import '../widgets/inventory_item_card.dart';
import 'item_detail_screen.dart';
import 'item_form_screen.dart';

/// Home/Item List screen (Week 1). Responsive layout: a single-column list
/// on phone-width screens, a multi-column grid on tablet/wide screens —
/// driven by [LayoutBuilder] reading the available width, not the device
/// type, so it also works with a resized desktop window.
///
/// Week 3 adds Add/Edit: the list lives in local widget state so edits
/// made through the form are reflected immediately. Week 4 promotes this
/// to shared app state (Riverpod) so it's no longer screen-local.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static const double _tabletBreakpoint = 600;

  late List<InventoryItem> _items = InventoryService().getItems();

  int _columnsFor(double width) {
    if (width >= 1000) return 4;
    if (width >= _tabletBreakpoint) return 3;
    return 1;
  }

  Future<void> _openDetail(InventoryItem item) async {
    final index = _items.indexOf(item);
    final result = await Navigator.of(context).push<InventoryItem>(
      MaterialPageRoute(builder: (_) => ItemDetailScreen(item: item)),
    );
    if (result != null && mounted) {
      setState(() => _items[index] = result);
    }
  }

  Future<void> _addItem() async {
    final result = await Navigator.of(context).push<InventoryItem>(
      MaterialPageRoute(builder: (_) => const ItemFormScreen()),
    );
    if (result != null && mounted) {
      setState(() => _items = [..._items, result]);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Retail Stock Tracker')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addItem,
        icon: const Icon(Icons.add),
        label: const Text('Add Item'),
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final columns = _columnsFor(constraints.maxWidth);

            if (columns == 1) {
              return ListView.separated(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 88),
                itemCount: _items.length,
                separatorBuilder: (_, _) => const SizedBox(height: 10),
                itemBuilder: (context, index) => InventoryItemCard(item: _items[index], onTap: () => _openDetail(_items[index])),
              );
            }

            return GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 88),
              itemCount: _items.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: columns,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.4,
              ),
              itemBuilder: (context, index) => InventoryItemCard(item: _items[index], onTap: () => _openDetail(_items[index])),
            );
          },
        ),
      ),
    );
  }
}
