import 'package:flutter/material.dart';
import '../models/inventory_item.dart';
import 'item_form_screen.dart';

/// Item Detail screen (Week 2). Reached by tapping a card on the Home
/// screen's list/grid. Week 3 adds the Edit action, which pops this
/// screen with the updated item so Home can apply the change.
class ItemDetailScreen extends StatelessWidget {
  final InventoryItem item;

  const ItemDetailScreen({super.key, required this.item});

  Future<void> _edit(BuildContext context) async {
    final result = await Navigator.of(context).push<InventoryItem>(
      MaterialPageRoute(builder: (_) => ItemFormScreen(initial: item)),
    );
    if (result != null && context.mounted) {
      Navigator.of(context).pop(result);
    }
  }

  @override
  Widget build(BuildContext context) {
    final outOfStock = item.quantity == 0;
    return Scaffold(
      appBar: AppBar(
        title: Text(item.name),
        actions: [
          IconButton(icon: const Icon(Icons.edit_outlined), tooltip: 'Edit item', onPressed: () => _edit(context)),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primaryContainer.withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(Icons.inventory_2_outlined, size: 64, color: Theme.of(context).colorScheme.primary),
            ),
            const SizedBox(height: 24),
            Text(item.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 16),
            _DetailRow(label: 'SKU / Code', value: item.sku),
            _DetailRow(label: 'Category', value: item.category),
            _DetailRow(
              label: 'Quantity',
              value: '${item.quantity}',
              valueColor: outOfStock ? Colors.red.shade700 : Colors.green.shade700,
            ),
            if (outOfStock) ...[
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: Colors.red.shade50, borderRadius: BorderRadius.circular(10)),
                child: Row(
                  children: [
                    Icon(Icons.warning_amber_rounded, color: Colors.red.shade700, size: 20),
                    const SizedBox(width: 8),
                    Expanded(child: Text('This item is out of stock.', style: TextStyle(color: Colors.red.shade700, fontWeight: FontWeight.w600))),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  final Color? valueColor;

  const _DetailRow({required this.label, required this.value, this.valueColor});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          SizedBox(width: 110, child: Text(label, style: TextStyle(color: Colors.grey.shade600, fontSize: 13))),
          Expanded(
            child: Text(value, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: valueColor)),
          ),
        ],
      ),
    );
  }
}
