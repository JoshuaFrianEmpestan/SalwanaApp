import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/inventory_item.dart';
import '../services/inventory_provider.dart';
import '../widgets/inventory_item_card.dart';
import 'item_detail_screen.dart';
import 'item_form_screen.dart';

/// Home/Item List screen (Week 1). Responsive layout: a single-column list
/// on phone-width screens, a multi-column grid on tablet/wide screens —
/// driven by [LayoutBuilder] reading the available width, not the device
/// type, so it also works with a resized desktop window.
///
/// Week 5: [inventoryProvider] is now backed by Firestore, so this reads
/// an [AsyncValue] and shows explicit loading/error states instead of
/// assuming the data is always already there.
class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  static const double _tabletBreakpoint = 600;

  int _columnsFor(double width) {
    if (width >= 1000) return 4;
    if (width >= _tabletBreakpoint) return 3;
    return 1;
  }

  Future<void> _openDetail(BuildContext context, InventoryItem item) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => ItemDetailScreen(item: item)));
  }

  Future<void> _addItem(BuildContext context, WidgetRef ref) async {
    final result = await Navigator.of(context).push<InventoryItem>(
      MaterialPageRoute(builder: (_) => const ItemFormScreen()),
    );
    if (result != null) {
      await ref.read(inventoryRepositoryProvider).addItem(result);
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final itemsAsync = ref.watch(inventoryProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Retail Stock Tracker')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _addItem(context, ref),
        icon: const Icon(Icons.add),
        label: const Text('Add Item'),
      ),
      body: SafeArea(
        child: itemsAsync.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, _) => Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.error_outline_rounded, size: 40, color: Colors.red),
                  const SizedBox(height: 12),
                  const Text('Could not load inventory.', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  Text('$error', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
                  const SizedBox(height: 16),
                  FilledButton.icon(
                    onPressed: () => ref.invalidate(inventoryProvider),
                    icon: const Icon(Icons.refresh_rounded),
                    label: const Text('Retry'),
                  ),
                ],
              ),
            ),
          ),
          data: (items) {
            if (items.isEmpty) {
              return const Center(child: Text('No items yet. Tap "Add Item" to get started.'));
            }
            return LayoutBuilder(
              builder: (context, constraints) {
                final columns = _columnsFor(constraints.maxWidth);

                if (columns == 1) {
                  return ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 88),
                    itemCount: items.length,
                    separatorBuilder: (_, _) => const SizedBox(height: 10),
                    itemBuilder: (context, index) => InventoryItemCard(item: items[index], onTap: () => _openDetail(context, items[index])),
                  );
                }

                return GridView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 88),
                  itemCount: items.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: columns,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: 1.4,
                  ),
                  itemBuilder: (context, index) => InventoryItemCard(item: items[index], onTap: () => _openDetail(context, items[index])),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
