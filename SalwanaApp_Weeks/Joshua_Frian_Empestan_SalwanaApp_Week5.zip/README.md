# Salwana -- Retail Stock Tracker (Week 5)

A responsive Flutter inventory app built week-by-week for the Responsive
Inventory System project. Retail stock tracker theme: items have a name,
SKU, quantity, and category.

**This week (5):** Adds real backend integration: Firestore-backed inventory, loading/error states, and Stock In/Out actions.

## Project structure

```
lib/
  models/    InventoryItem -- the data shape
  services/  InventoryService + inventoryProvider (Riverpod)
  widgets/   Shared widgets (AdaptiveNavScaffold, InventoryItemCard, ...)
  screens/   HomeScreen, ItemDetailScreen, ItemFormScreen, CategoriesScreen
```

## Week-by-week build order

Each week's zip in `SalwanaApp_Weeks/` is cumulative -- Week N contains
everything from Week 1 through N.

| Week | Focus | What was added |
|---|---|---|
| 1 | Setup + static responsive layout | Project scaffold, dummy-data Home/Item List screen, `LayoutBuilder`-driven responsive grid (1/3/4 columns by width) |
| 2 | Item detail + adaptive navigation | Item Detail screen; `AdaptiveNavScaffold` -- bottom nav bar under 600px, `NavigationRail` at/above it |
| 3 | Add/Edit forms + validation | `ItemFormScreen` (shared by Add/Edit) with required-field and numeric validators, `ResponsiveFormBody` |
| 4 | State management | `inventoryProvider` (Riverpod `Notifier`) -- shared app state instead of screen-local state |
| 5 | Stock In/Out + data integration | Firestore-backed `InventoryService`; `inventoryProvider` becomes a `StreamProvider` with real loading/error states; Stock In/Out buttons |
| 6 | Search, filter, alerts + orientation | Search by name/SKU, category filter chips, low-stock alert banner; layout is width-driven so it survives rotation |
| 7 | Offline support + polish | Firestore offline persistence + `OfflineBanner`; Hero transition + `AnimatedSwitcher` animation; accessibility tooltips |
| 8 | Final integration + packaging | README, final QA pass, demo-ready build |

## Running it

```
flutter pub get
flutter run
```

By default this expects a real Firebase project (see below). To run
against the local Firebase Emulator Suite instead (no real project
needed):

```
firebase emulators:start
flutter run --dart-define=USE_FIREBASE_EMULATOR=true
```

On Windows, the emulator connection in `lib/main.dart` deliberately uses
the literal `127.0.0.1` rather than `localhost`, since `localhost` can
resolve to the IPv6 loopback first, which the emulator never answers on.

## Connecting a real Firebase project

`lib/firebase_options.dart` currently contains placeholder ("demo-")
values. To connect a real project:

```
dart pub global activate flutterfire_cli
flutterfire configure
```

This overwrites `firebase_options.dart` with your project's real keys.
Enable Firestore in the Firebase Console for your project first.

## Building for Android

Building/running with Gradle for the first time downloads Gradle itself
and may take a few minutes. If you're on macOS/Linux and see a
"Permission denied" error running `gradlew`, run:

```
chmod +x android/gradlew
```
