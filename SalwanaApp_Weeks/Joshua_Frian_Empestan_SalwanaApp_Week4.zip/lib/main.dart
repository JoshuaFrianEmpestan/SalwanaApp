import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'screens/categories_screen.dart';
import 'screens/home_screen.dart';
import 'widgets/adaptive_nav_scaffold.dart';

void main() {
  runApp(const ProviderScope(child: SalwanaApp()));
}

class SalwanaApp extends StatelessWidget {
  const SalwanaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Salwana Retail Stock Tracker',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.green),
        useMaterial3: true,
      ),
      home: const AdaptiveNavScaffold(
        screens: [HomeScreen(), CategoriesScreen()],
        destinations: [
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2), label: 'Inventory'),
          NavigationDestination(icon: Icon(Icons.category_outlined), selectedIcon: Icon(Icons.category), label: 'Categories'),
        ],
      ),
    );
  }
}
