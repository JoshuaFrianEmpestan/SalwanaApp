import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/inventory_item.dart';
import 'inventory_service.dart';

/// Shared app state (Week 4) — the item list now lives here instead of in
/// Home screen's local state, so every screen (Home, Categories, Detail)
/// reads the same data and stays in sync when it changes.
class InventoryNotifier extends Notifier<List<InventoryItem>> {
  @override
  List<InventoryItem> build() => InventoryService().getItems();

  void addItem(InventoryItem item) {
    state = [...state, item];
  }

  void updateItem(InventoryItem original, InventoryItem updated) {
    state = [
      for (final item in state) item.sku == original.sku ? updated : item,
    ];
  }
}

final inventoryProvider = NotifierProvider<InventoryNotifier, List<InventoryItem>>(InventoryNotifier.new);
