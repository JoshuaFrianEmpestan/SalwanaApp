import '../models/inventory_item.dart';

/// Provides the item list for the Home screen. Week 1: hardcoded dummy
/// data, matching the assignment ("dummy/hardcoded data is fine for now").
/// Real backend/database integration is a later week's requirement — this
/// class is the seam that swap gets made through, so the screen above it
/// won't need to change shape when that happens.
class InventoryService {
  List<InventoryItem> getItems() {
    return const [
      InventoryItem(name: 'Wireless Mouse', sku: 'RS-1001', quantity: 42, category: 'Electronics'),
      InventoryItem(name: 'Mechanical Keyboard', sku: 'RS-1002', quantity: 15, category: 'Electronics'),
      InventoryItem(name: 'USB-C Cable 2m', sku: 'RS-1003', quantity: 120, category: 'Accessories'),
      InventoryItem(name: 'Bluetooth Speaker', sku: 'RS-1004', quantity: 8, category: 'Electronics'),
      InventoryItem(name: 'Notebook A5', sku: 'RS-2001', quantity: 200, category: 'Office Supplies'),
      InventoryItem(name: 'Ballpoint Pen (Box)', sku: 'RS-2002', quantity: 75, category: 'Office Supplies'),
      InventoryItem(name: 'Sticky Notes', sku: 'RS-2003', quantity: 60, category: 'Office Supplies'),
      InventoryItem(name: 'Desk Lamp', sku: 'RS-3001', quantity: 5, category: 'Furniture'),
      InventoryItem(name: 'Office Chair', sku: 'RS-3002', quantity: 3, category: 'Furniture'),
      InventoryItem(name: 'Whiteboard 60x90', sku: 'RS-3003', quantity: 12, category: 'Furniture'),
      InventoryItem(name: 'Phone Stand', sku: 'RS-1005', quantity: 30, category: 'Accessories'),
      InventoryItem(name: 'Laptop Sleeve 14"', sku: 'RS-1006', quantity: 0, category: 'Accessories'),
    ];
  }
}
