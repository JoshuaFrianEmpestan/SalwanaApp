/// A single stock item in the retail inventory (Week 1 — dummy data only,
/// real backend integration comes later in the build order).
class InventoryItem {
  final String name;
  final String sku;
  final int quantity;
  final String category;

  const InventoryItem({
    required this.name,
    required this.sku,
    required this.quantity,
    required this.category,
  });
}
