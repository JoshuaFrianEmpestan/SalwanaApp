import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/inventory_item.dart';
import '../services/inventory_provider.dart';
import '../widgets/inventory_item_card.dart';
import 'item_detail_screen.dart';
import 'item_form_screen.dart';

/// Home/Item List screen (Week 1). Responsive layout: a single-column list
/// on phone-width screens, a multi-column grid on tablet/wide screens —
/// driven by [LayoutBuilder] reading the available width, not the device
/// type, so it also works with a resized desktop window.
///
/// Week 4: reads from [inventoryProvider] (shared app state) instead of
/// screen-local state, so Add/Edit made here are visible everywhere else
/// too — e.g. the Categories tab's counts update immediately.
class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  static const double _tabletBreakpoint = 600;

  int _columnsFor(double width) {
    if (width >= 1000) return 4;
    if (width >= _tabletBreakpoint) return 3;
    return 1;
  }

  Future<void> _openDetail(BuildContext context, InventoryItem item) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => ItemDetailScreen(item: item)));
  }

  Future<void> _addItem(BuildContext context, WidgetRef ref) async {
    final result = await Navigator.of(context).push<InventoryItem>(
      MaterialPageRoute(builder: (_) => const ItemFormScreen()),
    );
    if (result != null) {
      ref.read(inventoryProvider.notifier).addItem(result);
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final items = ref.watch(inventoryProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Retail Stock Tracker')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _addItem(context, ref),
        icon: const Icon(Icons.add),
        label: const Text('Add Item'),
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final columns = _columnsFor(constraints.maxWidth);

            if (columns == 1) {
              return ListView.separated(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 88),
                itemCount: items.length,
                separatorBuilder: (_, _) => const SizedBox(height: 10),
                itemBuilder: (context, index) => InventoryItemCard(item: items[index], onTap: () => _openDetail(context, items[index])),
              );
            }

            return GridView.builder(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 88),
              itemCount: items.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: columns,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.4,
              ),
              itemBuilder: (context, index) => InventoryItemCard(item: items[index], onTap: () => _openDetail(context, items[index])),
            );
          },
        ),
      ),
    );
  }
}
