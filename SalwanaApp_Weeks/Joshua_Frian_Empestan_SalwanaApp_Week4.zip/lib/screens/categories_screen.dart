import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/inventory_provider.dart';

/// Categories overview — the second nav destination. Week 4: reads the
/// same shared [inventoryProvider] as Home, so a newly added item's
/// category shows up here immediately too.
class CategoriesScreen extends ConsumerWidget {
  const CategoriesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final items = ref.watch(inventoryProvider);
    final byCategory = <String, int>{};
    for (final item in items) {
      byCategory[item.category] = (byCategory[item.category] ?? 0) + 1;
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Categories')),
      body: SafeArea(
        child: ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: byCategory.length,
          separatorBuilder: (_, _) => const SizedBox(height: 10),
          itemBuilder: (context, index) {
            final entry = byCategory.entries.elementAt(index);
            return Card(
              margin: EdgeInsets.zero,
              child: ListTile(
                leading: const Icon(Icons.category_outlined),
                title: Text(entry.key, style: const TextStyle(fontWeight: FontWeight.w700)),
                trailing: Text('${entry.value} item${entry.value == 1 ? '' : 's'}', style: TextStyle(color: Colors.grey.shade600)),
              ),
            );
          },
        ),
      ),
    );
  }
}
