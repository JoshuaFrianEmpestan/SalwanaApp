import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:salwana_app/main.dart';

void main() {
  testWidgets('Home screen shows the inventory list', (WidgetTester tester) async {
    await tester.pumpWidget(const ProviderScope(child: SalwanaApp()));

    expect(find.text('Retail Stock Tracker'), findsOneWidget);
    expect(find.text('Wireless Mouse'), findsOneWidget);
  });
}
